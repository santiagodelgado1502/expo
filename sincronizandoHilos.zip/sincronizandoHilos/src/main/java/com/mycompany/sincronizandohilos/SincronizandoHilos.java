/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.sincronizandohilos;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author santi
 */
public class SincronizandoHilos {

    public static void main(String[] args) {
        
        HilosVarios hilo1= new HilosVarios();
        HilosVarios hilo2= new HilosVarios();
        
        hilo1.start();
        try {
            hilo1.join();
        } catch (InterruptedException ex) {
            Logger.getLogger(SincronizandoHilos.class.getName()).log(Level.SEVERE, null, ex);
        }
        hilo2.start();
        
        try {
            hilo2.join();
        } catch (InterruptedException ex) {
            Logger.getLogger(SincronizandoHilos.class.getName()).log(Level.SEVERE, null, ex);
        }
        
       System.out.println("Terminadas las tareas");
        
    }
}

class HilosVarios extends Thread{

    public void run(){
    
        for(int i=0; i< 15; i++){
        
            try {
                System.out.println("Ejecutando Hilo "+ getName());
                Thread.sleep(300);
            } catch (InterruptedException ex) {
                Logger.getLogger(HilosVarios.class.getName()).log(Level.SEVERE, null, ex);
            }
        
        }
        
    }
    
}
