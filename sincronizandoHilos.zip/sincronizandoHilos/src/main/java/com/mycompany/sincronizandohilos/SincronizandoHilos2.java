/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sincronizandohilos;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author santi
 */
public class SincronizandoHilos2 {
    
    public static void main(String[] args) {
        HilosVarios hilo1= new HilosVarios();
        
        HilosVarios2 hilo2= new HilosVarios2(hilo1);
        
        hilo2.start();
        
        hilo1.start();
                
       System.out.println("Terminadas las tareas");
    }
    
    
}
class HilosVarios extends Thread{

    public void run(){
    
        for(int i=0; i< 15; i++){
        
            try {
                System.out.println("Ejecutando Hilo "+ getName());
                Thread.sleep(300);
            } catch (InterruptedException ex) {
                Logger.getLogger(HilosVarios.class.getName()).log(Level.SEVERE, null, ex);
            }
        
        }
        
    }
    
}

class HilosVarios2 extends Thread{
    
    public HilosVarios2(Thread hilo){
    
        this.hilo=hilo;
        
    }

    public void run(){
        
        try {
            hilo.join();
        } catch (InterruptedException ex) {
            Logger.getLogger(HilosVarios2.class.getName()).log(Level.SEVERE, null, ex);
        }
    
        for(int i=0; i< 15; i++){
        
            try {
                System.out.println("Ejecutando Hilo "+ getName());
                Thread.sleep(300);
            } catch (InterruptedException ex) {
                Logger.getLogger(HilosVarios.class.getName()).log(Level.SEVERE, null, ex);
            }
        
        }
        
    }
    private Thread hilo;
    
}
